package com.example.flipkart.entity;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserEntity {
    private Integer id;
    private String name;
    private Integer credit;
}
