package com.example.flipkart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlipkartApplicationTests {

	@Test
	void contextLoads() {
	}

}
